from redis import StrictRedis
import logging


class Config(object):
    """封装配置的类"""

    # 项目秘钥：csrf、session等其他的扩展需要用到
    SECRET_KEY = "EjpNVSNQTyGi1VvWECj9TvC/+kq3oujee2kTfQUs8yCM6xX9Yjq52v54g+HVoknA"

    # 开启调试模式
    DEBUG = True

    # 配置MySQL数据库和创建数据库
    SQLALCHEMY_DATABASE_URI = 'mysql://root:mysql@127.0.0.1:3306/information'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # 配置Redis数据库
    REDIS_HOST = '127.0.0.1'
    REDIS_PORT = 6379

    # 配置session数据存储的位置
    SESSION_TYPE = "redis"  # 指定 session 保存到 redis 中
    SESSION_USE_SIGNER = True  # 让 cookie 中的 session_id 被加密签名处理
    SESSION_REDIS = StrictRedis(host=REDIS_HOST, port=REDIS_PORT)  # 使用 redis 的实例
    PERMANENT_SESSION_LIFETIME = 3600*24  # session 的有效期，单位是秒


class DevelopmentConfig(Config):
    """开发环境下的配置信息"""
    DEBUG = True
    # 日志等级
    LOG_LEVEL = logging.DEBUG


class ProductionConfig(Config):
    """生产环境下的配置信息"""
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = 'mysql://root:mysql@127.0.0.1:3306/information_production'
    # 日志等级
    LOG_LEVEL = logging.ERROR


class UnittestConfig(Config):
    """单元测试下的配置环境"""
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'mysql://root:mysql@127.0.0.1:3306/information_unittest'
    TESTING = True
    # 日志等级
    LOG_LEVEL = logging.DEBUG


# 定义环境字典
configs = {
    'dev':DevelopmentConfig,
    'pro':ProductionConfig,
    'unit':UnittestConfig
}



