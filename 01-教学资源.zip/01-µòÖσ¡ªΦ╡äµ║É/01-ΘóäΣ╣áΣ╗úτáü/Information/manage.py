from flask_script import Manager
from flask_migrate import Migrate, MigrateCommand
# from info import app, db
from info import create_app, db, models
from info.models import User


# 获取app:传入对应的环境
app = create_app('dev')

# 创建脚本管理器对象
manager = Manager(app)

# 迁移关联app和db
Migrate(app, db)
# 将迁移命令关联到manager
manager.add_command('mysql', MigrateCommand)


@manager.option('-u', '-username', dest='username')
@manager.option('-p', '-password', dest='password')
@manager.option('-m', '-mobile', dest='mobile')
def createsuperuser(username, password, mobile):
    """
    创建管理员的函数
    :param name: 管理员名字
    :param password: 管理员密码
    """
    if not all([username,password,mobile]):
        print('缺少参数')
    else:
        user = User()
        user.nick_name = username
        user.password = password
        user.mobile = mobile
        user.is_admin = True
        try:
            db.session.add(user)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            print(e)


if __name__ == '__main__':

    print(app.url_map)

    # app.run()
    manager.run()