from . import passport_blue
from info.utils.captcha.captcha import captcha
from flask import make_response, request, abort, current_app, jsonify, session
from info import redis_store, constants, response_code, db
import re, random, datetime
from info.libs.yuntongxun.sms import CCP
from info.models import User


@passport_blue.route('/logout', methods=['GET'])
def logout():
    """退出登录
    1.清空服务器session数据
    """
    try:
        session.pop('user_id',None)
        session.pop('mobile', None)
        session.pop('nick_name', None)

        # 为了防止admin登录到新经资讯后，留下管理员的权限，退出登录时需要将次标记页清除
        session.pop('is_admin', False)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='删除session数据失败')

    return jsonify(errno=response_code.RET.OK, errmsg='登出登录成功')


@passport_blue.route('/login', methods=['POST'])
def login():
    """登录
    1.接受参数（手机号，密码明文）
    2.校验参数是否缺少，手机号是否合法
    3.查询用户是否存在
    4.如果用户存在，校验密码是否正确
    5.保存最后一次登录时间
    6.将状态保持数据写入session
    7.响应登录结果
    """
    # 1.接受参数（手机号，密码明文）
    json_dict = request.json
    mobile = json_dict.get('mobile')
    password = json_dict.get('password')

    # 2.校验参数是否缺少
    if not all([mobile, password]):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
    if not re.match(r'^1[345678][0-9]{9}$', mobile):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='手机号格式错误')

    # 3.查询用户是否存在
    try:
        user = User.query.filter(User.mobile==mobile).first()
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='查询用户数据失败')
    if not user:
        return jsonify(errno=response_code.RET.NODATA, errmsg='用户名或密码错误')

    # 4.如果用户存在，校验密码是否正确
    if not user.check_password(password):
        return jsonify(errno=response_code.RET.NODATA, errmsg='用户名或密码错误')

    # 5.保存最后一次登录时间
    user.last_login = datetime.datetime.now()
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
        return jsonify(errno=response_code.RET.DBERR, errmsg='更新登录时间失败')

    # 6.将状态保持数据写入session
    session['user_id'] = user.id
    session['mobile'] = user.mobile
    session['nick_name'] = user.nick_name

    # 7.响应登录结果
    return jsonify(errno=response_code.RET.OK, errmsg='登录成功')


@passport_blue.route('/register', methods=['POST'])
def register():
    """注册
    1.接受参数（手机号，短信验证码，密码）
    2.校验参数是否齐全，手机号是否合法
    3.查询服务器存储的短信验证码
    4.用户输入的短信验证码和服务器存储的对比
    5.如果对比成功，创建User对象，并设置相关属性
    6.保存User对象到数据库
    7.将状态保持数据写入session
    8.响应注册结果
    """
    # 1.接受参数（手机号，短信验证码，密码）
    json_dict = request.json
    mobile = json_dict.get('mobile')
    sms_code_clinet = json_dict.get('smscode')
    password = json_dict.get('password')

    # 2.校验参数是否齐全，手机号是否合法
    if not all([mobile, sms_code_clinet, password]):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
    if not re.match(r'^1[345678][0-9]{9}$', mobile):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='手机号格式错误')

    # 3.查询服务器存储的短信验证码
    try:
        sms_code_server = redis_store.get('SMS:'+mobile)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询短信验证码失败')
    if not sms_code_server:
        return jsonify(errno=response_code.RET.NODATA, errmsg='短信验证码不存在')

    # 4.用户输入的短信验证码和服务器存储的对比
    if sms_code_clinet != sms_code_server:
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='短信验证码输入有误')

    # 5.如果对比成功，创建User对象，并设置相关属性
    user = User()
    user.mobile = mobile
    user.nick_name = mobile
    # 注意：密码需要加密处理
    user.password = password
    # 注意：记录用户最后一次登录时间
    user.last_login = datetime.datetime.now()

    # 6.保存User对象到数据库
    try:
        db.session.add(user)
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
        return jsonify(errno=response_code.RET.DBERR, errmsg='存储注册数据失败')

    # 7.将状态保持数据写入session
    session['user_id'] = user.id
    session['mobile'] = user.mobile
    session['nick_name'] = user.nick_name

    # 8.响应注册结果
    return jsonify(errno=response_code.RET.OK, errmsg='注册成功')


@passport_blue.route('/sms_code', methods=['POST'])
def send_sms_code():
    """发送短信验证码
    1.接受参数（手机号，验证码，验证码id）
    2.校验验证码是否齐全、手机号格式是否正确
    3.查询服务器存储的图片验证码
    4.用户输入的验证码和服务器存储的验证码进行对比
    5.如果对比成功，发送短信验证码
    6.存储短信验证码到服务器
    7.响应验证码发送结果
    """
    # 1.接受参数（手机号，验证码，验证码id）
    # json_str = request.data
    # import json
    # json_dict = json.loads(json_str)
    json_dict = request.json
    mobile = json_dict.get('mobile')
    image_code_client = json_dict.get('image_code')
    image_code_id = json_dict.get('image_code_id')

    # 2.校验验证码是否齐全、手机号格式是否正确
    if not all([mobile, image_code_client, image_code_id]):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
    if not re.match(r'^1[345678][0-9]{9}$', mobile):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='手机号格式错误')

    # 3.查询服务器存储的图片验证码
    try:
        image_code_server = redis_store.get('ImageCode:'+image_code_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询图片验证码失败')
    if not image_code_server:
        return jsonify(errno=response_code.RET.NODATA, errmsg='图片验证码不存在')

    # 4.使用用户输入的验证码和服务器存储的验证码进行对比
    if image_code_client.lower() != image_code_server.lower():
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='图片验证码输入有误')

    # 5.如果对比成功，发送短信验证码
    sms_code = '%06d' % random.randint(0, 999999)
    current_app.logger.debug(sms_code)
    # result = CCP().send_template_sms(mobile, [sms_code, '5'], '1')
    # if result != 0:
    #     return jsonify(errno=response_code.RET.THIRDERR, errmsg='发送短信验证码失败')

    # 6.存储短信验证码到服务器
    try:
        redis_store.set('SMS:'+mobile, sms_code, constants.SMS_CODE_REDIS_EXPIRES)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='存储短信验证码失败')

    # 7.响应验证码发送结果
    return jsonify(errno=response_code.RET.OK, errmsg='发送短信验证码成功')


@passport_blue.route('/image_code', methods=['GET'])
def get_image_code():
    """提供图片验证码
    1.获取参数imageCodeId(图片验证码的唯一识别符)
    2.校验参数,如果没有就403
    3.生成图片验证码
    4.保存图片验证码内容到redis数据库
    5.修改image的'Content-Type'为'image/jpg'
    6.响应图片验证码
    """
    # 1.获取参数imageCodeId
    imageCodeId = request.args.get('imageCodeId')

    # 2.校验参数,如果没有就403
    if not imageCodeId:
        abort(403)

    # 3.生成图片验证码
    name, text, image = captcha.generate_captcha()

    # 4.保存图片验证码内容到redis数据库
    try:
        redis_store.set('ImageCode:'+imageCodeId, text, constants.IMAGE_CODE_REDIS_EXPIRES)
    except Exception as e:
        current_app.logger.error(e)
        abort(500)

    # 5.修改image的'Content-Type'为'image/jpg'
    response = make_response(image)
    response.headers['Content-Type'] = 'image/jpg'

    # 6.响应图片验证码
    return response
