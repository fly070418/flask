# 用户模块
from . import user_blue
from flask import render_template,g,redirect,url_for,request,jsonify,current_app,session,abort
from info.utils.comment import user_login_data
from info import response_code,db,constants
from info.utils.file_storage import upload_file
from info.models import Category,News,User


@user_blue.route('/other_news_list')
def other_news_list():
    # 1.获取页数
    page = request.args.get("p", '1')
    other_id = request.args.get("user_id")

    # 2.校验参数
    try:
        p = int(page)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='参数错误')

    if not all([page, other_id]):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')

    # 3.查询用户数据
    try:
        user = User.query.get(other_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询用户数据失败')
    if not user:
        return jsonify(errno=response_code.RET.NODATA, errmsg='用户不存在')

    # 4.分页查询
    try:
        paginate = News.query.filter(News.user_id == user.id).paginate(p, constants.OTHER_NEWS_PAGE_MAX_COUNT, False)
        # 获取当前页数据
        news_list = paginate.items
        # 获取当前页
        current_page = paginate.page
        # 获取总页数
        total_page = paginate.pages
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询用户数据失败')

    # 5.构造响应数据
    news_dict_list = []
    for news_item in news_list:
        news_dict_list.append(news_item.to_review_dict())

    data = {
        "news_list": news_dict_list,
        "total_page": total_page,
        "current_page": current_page
    }

    # 6.渲染界面
    return jsonify(errno=response_code.RET.OK, errmsg='OK',data=data)


@user_blue.route('/other_info')
@user_login_data
def other_info():
    """其他用户信息"""
    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.获取参数
    other_id = request.args.get('user_id')

    # 3.校验参数
    if not other_id:
        abort(404)

    # 4.查询其他用户信息
    other = None
    try:
        other = User.query.get(other_id)
    except Exception as e:
        current_app.logger.error(e)
        abort(404)

    if not other:
        abort(404)

    # 关注和取消显示逻辑
    is_followed = False
    # 如果用户已登录,other对象在该登录用户的关注列表中
    if user and other:
        if other in user.followed:
            is_followed = True

    context = {
        'user':user.to_dict(),
        'other':other.to_dict(),
        'is_followed':is_followed
    }

    return render_template('news/other.html',context=context)


@user_blue.route('/user_follow')
@user_login_data
def user_follow():
    """我关注的用户"""

    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.接受参数
    page = request.args.get('p', '1')

    # 3.校验参数
    try:
        page = int(page)
    except Exception as e:
        current_app.logger.error(e)
        page = '1'

    # 3.查询登录用户的所关注的用户
    followed_users = []
    current_page = 1
    total_page = 1
    try:
        paginate = user.followed.paginate(page, constants.USER_FOLLOWED_MAX_COUNT, False)
        # 获取当前页数据
        followed_users = paginate.items
        # 获取当前页
        current_page = paginate.page
        # 获取总页数
        total_page = paginate.pages
    except Exception as e:
        current_app.logger.error(e)

    # 4.构造渲染数据
    followed_user_dict_list = []
    for followed_user in followed_users:
        followed_user_dict_list.append(followed_user.to_dict())

    context = {
        "users": followed_user_dict_list,
        "total_page": total_page,
        "current_page": current_page
    }

    # 5.响应结果
    return render_template('news/user_follow.html', context=context)


@user_blue.route('/news_list')
@user_login_data
def user_news_list():
    """用户发布的新闻"""

    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.获取参数（用户看第几页）
    page = request.args.get('p', '1')

    # 3.校验参数
    try:
        page = int(page)
    except Exception as e:
        current_app.logger.error(e)
        page = '1'

    # 4.查询用户发布的新闻列表
    paginate = None
    try:
        paginate = News.query.filter(News.user_id == user.id).paginate(page, constants.USER_COLLECTION_MAX_NEWS, False)
    except Exception as e:
        current_app.logger.error(e)

    # 5.构造响应数据
    news_list = paginate.items
    total_page = paginate.pages
    current_page = paginate.page

    news_dict_list = []
    for news in news_list:
        news_dict_list.append(news.to_review_dict())

    context = {
        'news_list':news_dict_list,
        'total_page':total_page,
        'current_page':current_page
    }

    # 6.渲染用户发布的新闻模板
    return render_template('news/user_news_list.html',context=context)


@user_blue.route('/news_release', methods=['GET','POST'])
@user_login_data
def user_news_release():
    """新闻发布"""

    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.GET请求逻辑
    if request.method == 'GET':
        # 2.1查询和渲染新闻分类数据
        categories = []
        try:
            categories = Category.query.all()
        except Exception as e:
            current_app.logger.error(e)

        # 2.2去掉'最新'标签
        categories.pop(0)

        # 2.3构造渲染数据
        context = {
            'categories':categories
        }

        # 2.4渲染界面
        return render_template('news/user_news_release.html',context=context)

    # 3.POST请求逻辑
    if request.method == 'POST':
        # 3.1 获取参数
        title = request.form.get("title")
        source = "个人发布"
        digest = request.form.get("digest")
        content = request.form.get("content")
        index_image = request.files.get("index_image")
        category_id = request.form.get("category_id")

        # 3.2 校验参数
        if not all([title, source, digest, content, index_image, category_id]):
            return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
        try:
            index_image = index_image.read()
        except Exception as e:
            current_app.logger.error(e)
            return jsonify(errno=response_code.RET.PARAMERR, errmsg='参数错误')

        # 3.3 上传新闻图片
        try:
            key = upload_file(index_image)
        except Exception as e:
            current_app.logger.error(e)
            return jsonify(errno=response_code.RET.THIRDERR, errmsg='上传图片失败')

        # 3.4 存储新闻数据
        news = News()
        news.title = title
        news.digest = digest
        news.source = source
        news.content = content
        news.index_image_url = constants.QINIU_DOMIN_PREFIX + key
        news.category_id = category_id
        news.user_id = user.id
        # 1代表待审核状态
        news.status = 1

        try:
            db.session.add(news)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(e)
            return jsonify(errno=response_code.RET.DBERR, errmsg='保存发布新闻数据失败')

        # 3.5 响应发布结果
        return jsonify(errno=response_code.RET.OK, errmsg='发布新闻成功')


@user_blue.route('/collection')
@user_login_data
def user_collection():
    """用户收藏的新闻"""

    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.获取参数（用户看第几页）
    page = request.args.get('p', '1')

    # 3.校验参数
    try:
        page = int(page)
    except Exception as e:
        current_app.logger.error(e)
        page = '1'

    # 4.查询登录用户收藏的新闻数据
    news_list = []
    current_page = 1
    total_page = 1
    try:
        paginate = user.collection_news.paginate(page, constants.USER_COLLECTION_MAX_NEWS, False)
        news_list = paginate.items
        current_page = paginate.page
        total_page = paginate.pages
    except Exception as e:
        current_app.logger.error(e)

    news_dict_list = []
    for news in news_list:
        news_dict_list.append(news.to_basic_dict())

    # 5.构造响应数据
    context = {
        'news_dict_list':news_dict_list,
        'current_page':current_page,
        'total_page':total_page
    }

    # 渲染界面
    return render_template('news/user_collection.html', context=context)


@user_blue.route('/pass_info', methods=['GET','POST'])
@user_login_data
def pass_info():
    """密码修改"""

    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.渲染密码修改界面
    if request.method == 'GET':
        return render_template('news/user_pass_info.html')

    # 3.实现密码修改逻辑
    if request.method == 'POST':
        # 3.1接受参数
        old_password = request.json.get('old_password')
        new_password = request.json.get('new_password')

        # 3.2校验参数
        if not all([old_password,new_password]):
            return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')

        # 3.3校验原始密码
        if not user.check_password(old_password):
            return jsonify(errno=response_code.RET.PARAMERR, errmsg='原密码错误')

        # 3.4设置新密码
        user.password = new_password
        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(e)
            return jsonify(errno=response_code.RET.DBERR, errmsg='保存新密码失败')

        # 3.5响应修改结果
        return jsonify(errno=response_code.RET.OK, errmsg='密码修改成功')


@user_blue.route('/pic_info', methods=['GET','POST'])
@user_login_data
def pic_info():
    """用户头像上传"""

    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.渲染用户头像界面
    if request.method == 'GET':
        context = {
            'user': user.to_dict()
        }
        return render_template('news/user_pic_info.html', context=context)

    # 3.上传用户头像
    if request.method == 'POST':
        # 3.1 获取上传的图片
        try:
            avatar_data = request.files.get('avatar').read()
        except Exception as e:
            current_app.logger.error(e)
            return jsonify(errno=response_code.RET.PARAMERR, errmsg='获取参数失败')

        # 3.2 上传头像
        try:
            key = upload_file(avatar_data)
        except Exception as e:
            current_app.logger.error(e)
            return jsonify(errno=response_code.RET.THIRDERR, errmsg='七牛上传失败')

        # 3.3 保存图片上传后的唯一标识
        user.avatar_url = key
        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(e)
            return jsonify(errno=response_code.RET.DBERR, errmsg='保存用户头像失败')

        # 响应上传结果
        data = {
            'avatar_url':constants.QINIU_DOMIN_PREFIX + key
        }
        return jsonify(errno=response_code.RET.OK, errmsg='上传头像成功', data=data)


@user_blue.route('/base_info', methods=['GET','POST'])
@user_login_data
def base_info():
    """基本资料"""

    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.渲染用户基本界面
    if request.method == 'GET':
        context = {
            'user':user.to_dict()
        }
        return render_template('news/user_base_info.html', context=context)

    # 3.修改用户基本资料：签名，昵称，性别
    if request.method == 'POST':
        # 3.1.接受参数
        nick_name = request.json.get('nick_name')
        signature = request.json.get('signature')
        gender = request.json.get('gender')

        # 3.2.校验参数
        if not all([nick_name,signature,gender]):
            return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
        if gender not in ['MAN','WOMEN']:
            return jsonify(errno=response_code.RET.PARAMERR, errmsg='参数错误')

        # 3.3.更新基本资料数据
        user.nick_name = nick_name
        user.signature = signature
        user.gender = gender
        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(e)
            return jsonify(errno=response_code.RET.DBERR, errmsg='更新资料失败')

        # 4.修改session中的nick_name
        session['nick_name'] = nick_name

        # 5.响应更新数据的结果
        return jsonify(errno=response_code.RET.OK, errmsg='更新资料成功')


@user_blue.route('/info')
@user_login_data
def user_info():
    """用户中心用户信息"""

    # 1.获取登录用户信息
    user = g.user
    if not user:
        # 如果用户未登录，重定向到index蓝图中的index视图
        return redirect(url_for('index.index'))

    # 2.构造渲染数据
    context = {
        'user':user.to_dict()
    }

    # 3.渲染界面
    return render_template('news/user.html', context=context)
