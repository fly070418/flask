from flask import Blueprint


# 创建首页模块的蓝图
index_blue = Blueprint('index', __name__)

from . import views