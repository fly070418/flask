from . import index_blue
from flask import render_template, current_app, session, request, jsonify,g
from info.models import User, News, Category
from info import constants, response_code
from info.utils.comment import user_login_data


@index_blue.route('/news_list')
def index_news_list():
    """注册新闻列表
    1.获取参数：新闻分类id，当前展示第几页，每页加载多少条
    2.校验参数：要求参数都必须是整数
    3.根据参数查询用户想看的数据：需要分类和排序和分页
    4.构造新闻响应数据
    5.响应新闻数据
    """
    # 1.获取参数：新闻分类id，当前展示第几页，每页加载多少条
    cid = request.args.get('cid', '1')
    page = request.args.get('page', '1')
    per_page = request.args.get('per_page', '10')

    # 2.校验参数：要求参数都必须是整数
    try:
        cid = int(cid)
        page = int(page)
        per_page = int(per_page)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='参数错误')

    # 3.根据参数查询用户想看的数据：需要分类和排序和分页
    try:
        if cid == 1:
            # 查询'最新'分类的新闻
            paginate = News.query.filter(News.status==0).order_by(News.create_time.desc()).paginate(page, per_page, False)
        else:
            # 查询指定分类的新闻
            paginate = News.query.filter(News.status==0,News.category_id==cid).order_by(News.create_time.desc()).paginate(page, per_page, False)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询新闻数据失败')

    # 获取当前页的数据
    news_list = paginate.items
    # 总页数
    total_page = paginate.pages
    # 当前页数
    current_page = paginate.page

    # 将模型对象列表news_list，转成字典列表
    news_dict_list = []
    for news in news_list:
        news_dict_list.append(news.to_basic_dict())

    # 4.构造新闻响应数据
    data = {
        'news_dict_list':news_dict_list,
        'total_page':total_page,
        'current_page':current_page
    }

    # 5.响应新闻数据
    return jsonify(errno=response_code.RET.OK, errmsg='OK', data=data)


@index_blue.route('/')
@user_login_data
def index():
    """主页
    1.获取登录的用户信息
    2.获取新闻点击排行数据
    3.展示新闻分类
    """
    # 1.获取登录的用户信息
    user = g.user

    # 2.获取新闻点击排行数据
    news_clicks = None
    try:
        news_clicks = News.query.order_by(News.clicks.desc()).limit(constants.CLICK_RANK_MAX_NEWS)
    except Exception as e:
        current_app.logger.error(e)

    # 3.展示新闻分类
    categories = Category.query.all()

    # 构造模板上下文
    context = {
        'user':user.to_dict() if user else None,
        'news_clicks':news_clicks,
        'categories':categories
    }

    # 渲染主页
    return render_template('news/index.html', context=context)


# http://127.0.0.1:5000/favicon.ico
@index_blue.route('/favicon.ico')
def favicon():
    """加载网站title图标"""
    return current_app.send_static_file('news/favicon.ico')

