# 新闻详情
from . import news_blue
from flask import render_template,session,current_app,g,abort,request,jsonify
from info.models import User,News, Comment, CommentLike
from info import constants,db,response_code
from info.utils.comment import user_login_data


@news_blue.route('/followed_user', methods=['POST'])
@user_login_data
def followed_user():
    """关注和取消关注"""
    # 1.获取登录用户信息
    login_user = g.user
    if not login_user:
        return jsonify(errno=response_code.RET.SESSIONERR, errmsg='用户未登录')

    # 2.接受参数
    user_id = request.json.get('user_id')
    action = request.json.get('action')

    # 3.校验参数
    if not all([user_id,action]):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
    if action not in ['follow','unfollow']:
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='参数错误')

    # 4.查询要被关注的用户是否存在
    try:
        other = User.query.get(user_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询用户数据失败')
    if not other:
        return jsonify(errno=response_code.RET.NODATA, errmsg='用户不存在')

    # 5.实现关注和取消关注逻辑
    if action == 'follow':
        # 关注
        if other not in login_user.followed:
            login_user.followed.append(other)
        else:
            return jsonify(errno=response_code.RET.DATAEXIST, errmsg='已关注')
    else:
        # 取消关注
        if other in login_user.followed:
            login_user.followed.remove(other)
        else:
            return jsonify(errno=response_code.RET.NODATA, errmsg='未关注')

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='操作失败')

    # 6.响应结果
    return jsonify(errno=response_code.RET.OK, errmsg='操作成功')


@news_blue.route('/comment_like', methods=['POST'])
@user_login_data
def comment_like():
    """评论点赞
    1.获取登录用户信息,未登录响应4101
    2.获取请求参数(评论id，点赞事件)
    3.校验参数
    4.查询评论信息是否存在
    5.点赞和取消点赞
    6.响应结果
    """
    # 1.获取登录用户信息
    user = g.user
    if not user:
        return jsonify(errno=response_code.RET.SESSIONERR, errmsg='用户未登录')

    # 2.获取请求参数
    comment_id = request.json.get('comment_id')
    action = request.json.get('action')

    # 3.校验参数
    if not all([comment_id,action]):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
    if action not in ['add', 'remove']:
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='参数错误')

    # 4.查询评论信息是否存在
    try:
        comment = Comment.query.get(comment_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询评论信息失败')
    if not comment:
        return jsonify(errno=response_code.RET.NODATA, errmsg='评论信息不存在')

    # 5.点赞和取消点赞
    if action == 'add':
        # 点赞:先查询该用户是否给该评论点赞了，如果没有点赞就点赞
        comment_like_model = CommentLike.query.filter(CommentLike.user_id==user.id,CommentLike.comment_id==comment_id).first()
        if not comment_like_model:
            # 创建点赞模型对象，这是一条新的点赞记录
            comment_like_model = CommentLike()
            comment_like_model.user_id = user.id
            comment_like_model.comment_id = comment_id
            # 新增点赞
            db.session.add(comment_like_model)
            # 增加点赞条数
            comment.like_count += 1
    else:
        # 取消点赞：先查询该用户是否给该评论点赞了，如果点赞了就取消点赞
        comment_like_model = CommentLike.query.filter(CommentLike.user_id == user.id,
                                                      CommentLike.comment_id == comment_id).first()
        if comment_like_model:
            # 删除点赞
            db.session.delete(comment_like_model)
            # 减少点赞条数
            comment.like_count -= 1

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='操作失败')

    # 6.响应结果
    return jsonify(errno=response_code.RET.OK, errmsg='操作成功')


@news_blue.route('/news_comment', methods=['POST'])
@user_login_data
def news_comment():
    """新闻评论和回复别人的评论
    1.获取登录用户信息(只有登录用户才可以评论)
    2.获取请求参数
    3.校验请求参数
    4.校验新闻是否存在
    5.初始化评论模型对象，并赋值,同步到数据库
    6.响应评论结果
    """
    # 1.获取登录用户信息
    user = g.user
    if not user:
        return jsonify(errno=response_code.RET.SESSIONERR, errmsg='用户未登录')

    # 2.获取请求参数
    news_id = request.json.get('news_id')
    comment_content = request.json.get('comment')
    # 没有parent_id表示评论信息；反之，是回复评论
    parent_id = request.json.get('parent_id')

    # 3.校验请求参数
    if not all([news_id,comment_content]):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
    try:
        news_id = int(news_id)
        if parent_id:
            parent_id = int(parent_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')

    # 4.校验新闻是否存在
    try:
        news = News.query.get(news_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询新闻数据失败')
    if not news:
        return jsonify(errno=response_code.RET.NODATA, errmsg='新闻数据不存在')

    # 5.初始化评论模型对象，并赋值
    comment = Comment()
    comment.user_id = user.id
    comment.news_id = news_id
    comment.content = comment_content
    if parent_id:
        comment.parent_id = parent_id

    try:
        db.session.add(comment)
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
        return jsonify(errno=response_code.RET.DBERR, errmsg='存储评论数据失败')

    # 6.响应评论结果:将评论信息返回给客户端用于渲染界面
    return jsonify(errno=response_code.RET.OK, errmsg='OK',data=comment.to_dict())


@news_blue.route('/news_collect', methods=['POST'])
@user_login_data
def news_collect():
    """新闻收藏
    1.获取登录用户信息(登录才能收藏，哪个用户收藏哪个新闻)
    2.获取参数（要收藏的新闻id,收藏或取消收藏行为）
    3.校验参数(是否登录，news_id是否存在)
    4.查询要收藏和取消收藏的新闻信息
    5.收藏和取消收藏
    6.响应结果
    """
    # 1.获取登录用户信息
    user = g.user
    if not user:
        return jsonify(errno=response_code.RET.SESSIONERR, errmsg='用户未登录')

    # 2.获取参数
    json_dict = request.json
    news_id = json_dict.get('news_id')
    action = json_dict.get('action')

    # 3.校验参数
    if not all([news_id,action]):
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')
    if action not in ['collect','cancel_collect']:
        return jsonify(errno=response_code.RET.PARAMERR, errmsg='缺少参数')

    # 4.查询要收藏的新闻信息
    try:
        news = News.query.get(news_id)
    except Exception as e:
        current_app.logger.error(e)
        return jsonify(errno=response_code.RET.DBERR, errmsg='查询新闻数据失败')
    if not news:
        return jsonify(errno=response_code.RET.NODATA, errmsg='新闻数据不存在')

    # 5.收藏和取消收藏
    if action == 'collect':
        # 如果该新闻没有被收藏就设置到用户的收藏列表
        if news not in user.collection_news:
            user.collection_news.append(news)
    else:
        if news in user.collection_news:
            user.collection_news.remove(news)

    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()
        return jsonify(errno=response_code.RET.DBERR, errmsg="操作失败")

    # 6.响应结果
    return jsonify(errno=response_code.RET.OK, errmsg="操作成功")


@news_blue.route('/detail/<int:news_id>')
@user_login_data
def news_detail(news_id):
    """
    新闻详情
    :param news_id: 新闻的id
    1.获取登录的用户信息
    2.获取新闻点击排行数据
    3.根据新闻id查询新闻详情信息
    4.是否收藏逻辑
    5.查询新闻评论数据
    6.该登录用户给该新闻的哪些评论点了赞
    7.关注和取消关注显示逻辑
    """

    # 1.获取登录的用户信息
    user = g.user

    # 2.获取新闻点击排行数据
    news_clicks = None
    try:
        news_clicks = News.query.order_by(News.clicks.desc()).limit(constants.CLICK_RANK_MAX_NEWS)
    except Exception as e:
        current_app.logger.error(e)

    # 3.1 根据新闻id查询新闻详情信息
    news = None
    try:
        news = News.query.get(news_id)
    except Exception as e:
        current_app.logger.error(e)

    # 3.2 判断新闻是否查询到:后续会对404做一个统一展示的页面
    if not news:
        abort(404)

    # 3.3 更新新闻的点击量
    news.clicks += 1
    try:
        db.session.commit()
    except Exception as e:
        current_app.logger.error(e)
        db.session.rollback()

    # 4.是否收藏逻辑
    is_collected = False # 默认未收藏

    if user:
        # 判断用户是否收藏该新闻
        if news in user.collection_news:
            # 如果未收藏
            is_collected = True

    # 5.查询新闻评论数据
    comments = []
    try:
        comments = Comment.query.filter(Comment.news_id==news_id).order_by(Comment.create_time.desc()).all()
    except Exception as e:
        current_app.logger.error(e)

    # 6.该登录用户给该新闻的哪些评论点了赞
    comment_like_ids = []
    if user:
        try:
            # 取出当前新闻所有的评论的评论id
            comment_ids = [comment.id for comment in comments]
            # 再查询当前评论中，哪些评论是被当前用户所点赞
            comment_likes = CommentLike.query.filter(CommentLike.comment_id.in_(comment_ids), CommentLike.user_id==user.id).all()
            # 取出所有被点赞的评论id
            comment_like_ids = [comment_like.comment_id for comment_like in comment_likes]
        except Exception as e:
            current_app.logger.error(e)

    comment_dict_list = []
    for comment in comments:
        # 给评论字典增加一个key,记录该评论是否被该用户点赞
        comment_dict = comment.to_dict()
        # 根据is_like判断是否点赞
        comment_dict['is_like'] = False # 默认未点赞
        if comment.id in comment_like_ids:
            comment_dict['is_like'] = True
        comment_dict_list.append(comment_dict)

    # 7.关注和取消显示逻辑
    is_followed = False
    # 如果用户已登录且该新闻有作者，并且该新闻的作者被该登录用户关注
    if user and news.user:
        if news.user in user.followed:
            is_followed = True

    context = {
        'user': user.to_dict() if user else None,
        'news_clicks': news_clicks,
        'news':news.to_dict(),
        'is_collected':is_collected,
        'comments':comment_dict_list,
        'is_followed':is_followed
    }

    return render_template('news/detail.html', context=context)