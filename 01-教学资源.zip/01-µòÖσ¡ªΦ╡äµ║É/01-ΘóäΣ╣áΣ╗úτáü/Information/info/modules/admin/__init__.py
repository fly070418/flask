from flask import Blueprint,session,redirect,url_for,request


# 创建首页模块的蓝图
admin_blue = Blueprint('admin', __name__, url_prefix='/admin')

from . import views


@admin_blue.before_request
def check_admin():
    is_admin = session.get('is_admin', False)
    if not is_admin and not request.url.endswith(url_for('admin.admin_login')):
        return redirect(url_for('index.index'))