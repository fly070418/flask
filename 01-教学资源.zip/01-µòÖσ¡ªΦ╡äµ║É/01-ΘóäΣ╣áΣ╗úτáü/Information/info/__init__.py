from flask import Flask,render_template,g
from flask_sqlalchemy import SQLAlchemy
from redis import StrictRedis
from flask_wtf import CSRFProtect, csrf
from flask_session import Session
# from config import Config, DevelopmentConfig, ProductionConfig, UnittestConfig
from config import configs
import logging
from logging.handlers import RotatingFileHandler


def setup_log(leave_name):
    """根据不同的环境，指定不同的日志等级"""

    # 设置日志的记录等级
    logging.basicConfig(level=leave_name) # 调试debug级
    # 创建日志记录器，指明日志保存的路径、每个日志文件的最大大小、保存的日志文件个数上限
    file_log_handler = RotatingFileHandler("logs/log", maxBytes=1024*1024*100, backupCount=10)
    # 创建日志记录的格式 日志等级 输入日志信息的文件名 行数 日志信息
    formatter = logging.Formatter('%(levelname)s %(filename)s:%(lineno)d %(message)s')
    # 为刚创建的日志记录器设置日志记录格式
    file_log_handler.setFormatter(formatter)
    # 为全局的日志工具对象（flask app使用的）添加日志记录器
    logging.getLogger().addHandler(file_log_handler)


# 创建连接到MySQL数据库的对象
db = SQLAlchemy()
# 创建连接到Redis数据库的对象
redis_store = None


def create_app(config_name):
    """创建app实例
    config_name : manage.py文件中传入的环境名字
    """

    # 配置日志
    setup_log(configs[config_name].LOG_LEVEL)

    app = Flask(__name__)

    # 从对象中加载配置
    app.config.from_object(configs[config_name])

    # 创建连接到数据库的对象
    # db = SQLAlchemy(app)
    db.init_app(app)

    # 创建连接到redis数据库的对象
    global redis_store
    redis_store = StrictRedis(host=configs[config_name].REDIS_HOST, port=configs[config_name].REDIS_PORT, decode_responses=True)

    # 开启CSRF保护
    # 帮我们实现的：取出cookie中的和表单中的csrf_token进行校验
    # 要自己实现的：向cookie中写入csrf_token，向表单中写入隐藏的csrf_token
    # 如果使用的是ajax提交的请求，可以将cookie中的csrf_token取出来放在headers中发送给服务器
    CSRFProtect(app)

    # 使用请求勾子将csrf_token写入到cookie
    # after_request装饰器 : 该请求勾子会自动的读取响应报文，将响应报文封装成响应对象，传入到被装饰的函数的参数中
    @app.after_request
    def after_request(response):
        # 生成csrf随机值
        csrf_token = csrf.generate_csrf()
        response.set_cookie('csrf_token', csrf_token)
        return response

    # 准备404错误页面
    from info.utils.comment import user_login_data
    @app.errorhandler(404)
    @user_login_data
    def page_not_found(e):
        context = {'user':g.user.to_dict()}
        return render_template('news/404.html',context=context)

    # 配置Session
    Session(app)

    # 添加自定义的过滤器
    from info.utils.comment import do_rank
    app.add_template_filter(do_rank, 'rank')

    # 测试蓝图:为了避免导入模块的问题，蓝图一般在哪里使用就在哪里导入
    from info.modules.index import index_blue
    app.register_blueprint(index_blue)
    from info.modules.passport import passport_blue
    app.register_blueprint(passport_blue)
    from info.modules.news import news_blue
    app.register_blueprint(news_blue)
    from info.modules.user import user_blue
    app.register_blueprint(user_blue)

    from info.modules.admin import admin_blue
    app.register_blueprint(admin_blue)

    return app